<?php
// Database connection

$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "rent_management_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM enq_comm WHERE id=$id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "No record found";
        exit();
    }
} else {
    echo "No ID provided";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Record</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            justify-content: center;
        }
        .record-container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            margin-bottom: 20px;
        }
        .record-container h1 {
            text-align: center;
            margin-bottom: 20px;
        }
        .record-container p {
            margin: 10px 0;
            font-size: 18px;
        }
        .print-button {
            display: block;
            width: 150px;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .print-button:hover {
            background-color: #0069d9;
        }
        .back-link {
            display: block;
            text-align: center;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            width: 200px;
            transition: background-color 0.3s ease;
        }
        .back-link:hover {
            background-color: #0069d9;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        function printPDF() {
            const element = document.querySelector('.record-container');
            html2pdf().from(element).save();
        }
    </script>
</head>
<body>
    <div class="record-container">
        <h1>Contact Details</h1>
        <p><strong>ID:</strong> <?php echo $row['id']; ?></p>
        <p><strong>Name:</strong> <?php echo $row['name']; ?></p>
        <p><strong>Age:</strong> <?php echo $row['age']; ?></p>
        <p><strong>Gender:</strong> <?php echo $row['gender']; ?></p>
        <p><strong>Address:</strong> <?php echo $row['address']; ?></p>
        <p><strong>Date of Enquiry:</strong> <?php echo $row['time_of_saving']; ?></p>
        <p><strong>Contact No.:</strong> <?php echo $row['mobile']; ?></p>
        <button class="print-button" onclick="printPDF()">Print to PDF</button>
    </div>

    <a href="enq_comm.php" class="back-link">Go Back to Records page</a>

    <script>
        document.querySelector('.back-link').addEventListener('mouseover', function() {
            this.style.backgroundColor = '#0069d9';
        });
        document.querySelector('.back-link').addEventListener('mouseout', function() {
            this.style.backgroundColor = '#007bff';
        });
    </script>
</body>
</html>
