<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Location</title>
    <link rel="stylesheet" href="styles11.css">
</head>
<body>
    <div class="content">
        <div id="mapContainer">
            <iframe src="https://www.google.com/maps/embed?pb=!1m26!1m12!1m3!1d224.871037742979!2d85.1508438985214!3d25.607022778436473!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m11!3e9!4m3!3m2!1d25.6068686!2d85.15102189999999!4m5!1s0x39ed588b1964d779%3A0xd97cecb8666dc308!2sUpadhyay%20Ln%2C%20West%20Lohanipur%2C%20Lohanipur%2C%20Patna%2C%20Bihar%20800003!3m2!1d25.6057955!2d85.15096109999999!5e0!3m2!1sen!2sin!4v1719842826275!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <button id="copyLink">Click to copy link</button>
        <button id="goback"><a href="../index.php">Go to home page</a></button>
    </div>

    <script src="script11.js"></script>
</body>
</html>
