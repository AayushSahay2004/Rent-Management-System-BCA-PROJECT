<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>See Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: auto;
            overflow: hidden;
        }
        .section {
            margin: 20px 0;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .section h2 {
            margin-top: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .print-button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="section">
            <h2>Bill Details</h2>
            <table>
                <tr>
                    <th>Serial Number</th>
                    <th>ID</th>
                    <th>Renter ID</th>
                    <th>Month</th>
                    <th>Year</th>
                    <th>Due Date</th>
                    <th>Room Rent</th>
                    <th>Units Used</th>
                    <th>Electric Bill</th>
                    <th>Advance Paid</th>
                    <th>Amount Dues</th>
                    <th>Miscellaneous</th>
                    <th>Total Amount</th>
                    <th>Created At</th>
                </tr>
                <?php
                // Database connection
                $conn = new mysqli('localhost', 'root', '', 'rent_management_system');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch data from bill_details table
                $sql = "SELECT * FROM bill_details";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    $serial_number = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$serial_number}</td>
                                <td>{$row['id']}</td>
                                <td>{$row['renter_id']}</td>
                                <td>{$row['month']}</td>
                                <td>{$row['year']}</td>
                                <td>{$row['due_date']}</td>
                                <td>{$row['room_rent']}</td>
                                <td>{$row['units_used']}</td>
                                <td>{$row['electric_bill']}</td>
                                <td>{$row['advance_paid']}</td>
                                <td>{$row['amount_dues']}</td>
                                <td>{$row['miscellaneous']}</td>
                                <td>{$row['total_amount']}</td>
                                <td>{$row['created_at']}</td>
                              </tr>";
                        $serial_number++;
                    }
                } else {
                    echo "<tr><td colspan='14'>No records found</td></tr>";
                }

                // Close connection
                $conn->close();
                ?>
            </table>
        </div>
        
        <div class="section">
            <h2>Payment Records</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Renter ID</th>
                    <th>Date of Payment</th>
                    <th>Month</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Description</th>
                </tr>
                <?php
                // Database connection
                $conn = new mysqli('localhost', 'root', '', 'rent_management_system');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch data from payment_status table
                $sql = "SELECT * FROM payment_status";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['renter_id']}</td>
                                <td>{$row['date_pay']}</td>
                                <td>{$row['month']}</td>
                                <td>{$row['amount']}</td>
                                <td>{$row['pay_status']}</td>
                                <td>{$row['description']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No records found</td></tr>";
                }

                // Close connection
                $conn->close();
                ?>
            </table>
        </div>
        
        <button class="print-button" onclick="window.print()">Produce Copies</button>
    </div>
</body>
</html>
