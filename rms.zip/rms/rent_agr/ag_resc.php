<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agreement Form</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], input[type="file"] {
            padding: 8px;
            margin-bottom: 12px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
        }

        input[type="file"] {
            cursor: pointer;
        }

        #preview {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }

        #preview div {
            width: calc(33.33% - 10px);
            margin-bottom: 10px;
        }

        #preview img {
            max-width: 100%;
            height: auto;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 style="text-align: center;">Agreement Form</h2>
        <form id="agreementForm" action="process_agreement.php" method="post" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>

            <label for="room_id">Room ID:</label>
            <input type="text" name="room_id" id="room_id" required>

            <label for="photo">Upload Photograph:</label>
            <input type="file" name="photo" id="photo" accept="image/*" required>

            <label for="signature">Upload Signature:</label>
            <input type="file" name="signature" id="signature" accept="image/*" required>

            <label for="aadhar">Upload Aadhar Card:</label>
            <input type="file" name="aadhar" id="aadhar" accept="image/*" required>

            <div id="preview">
                <div>
                    <p>Photo Preview:</p>
                    <img id="photoPreview" src="#">
                </div>
                <div>
                    <p>Signature Preview:</p>
                    <img id="signaturePreview" src="#">
                </div>
                <div>
                    <p>Aadhar Card Preview:</p>
                    <img id="aadharPreview" src="#">
                </div>
            </div>

            <input type="submit" value="Submit">
        </form>
        <a href="../index.php">Go to Home Page</a>
        <a href="print_agr.php">Produce the Agreement PDF</a>
    </div>

    <script>
        document.getElementById('photo').onchange = function (event) {
            const [file] = event.target.files;
            if (file) {
                document.getElementById('photoPreview').src = URL.createObjectURL(file);
            }
        };

        document.getElementById('signature').onchange = function (event) {
            const [file] = event.target.files;
            if (file) {
                document.getElementById('signaturePreview').src = URL.createObjectURL(file);
            }
        };

        document.getElementById('aadhar').onchange = function (event) {
            const [file] = event.target.files;
            if (file) {
                document.getElementById('aadharPreview').src = URL.createObjectURL(file);
            }
        };

        document.getElementById('agreementForm').onsubmit = function(event) {
            event.preventDefault();
            var formData = new FormData(this);

            fetch('process_agreement.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert("An error occurred while submitting the form. Please try again.");
            });
        };
    </script>
</body>
</html>
