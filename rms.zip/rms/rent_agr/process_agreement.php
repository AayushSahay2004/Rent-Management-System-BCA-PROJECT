<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array('success' => false, 'message' => 'File upload failed.');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $room_id = $_POST['room_id'];
    $currentTime = time();
    $folderName = "entry" . $room_id . $name;

    $target_dir = "stores/" . $folderName . "/";

    // Ensure the target directory exists
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // File paths
    $photo_path = $target_dir . "photo.jpg";
    $sign_path = $target_dir . "sign.jpg";
    $aadhar_path = $target_dir . "aadhar.jpg";

    // Move uploaded files
    if (move_uploaded_file($_FILES["photo"]["tmp_name"], $photo_path) &&
        move_uploaded_file($_FILES["signature"]["tmp_name"], $sign_path) &&
        move_uploaded_file($_FILES["aadhar"]["tmp_name"], $aadhar_path)) {
        
        // Insert file paths into the database
        $stmt = $conn->prepare("INSERT INTO entries (room_id, photo_path, sign_path, aadhar_path) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $room_id, $photo_path, $sign_path, $aadhar_path);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Files have been uploaded and stored successfully.';
        }

        $stmt->close();
    }
}

$conn->close();
echo json_encode($response);
?>
