<?php
session_start();
include("connection.php");
include("functions.php");
$user_data=check_login($con);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
        <a href="/"><img src="./assets/imp-logo-rms.png" width="" height="32" alt=""></a>
        <div class="nav-country">
            <img src="./assets/location_icon.png" height="20" alt="">
            <div>
                <p>Share</p>
                <h1><a href="loc_office/loc_office.php">Location</a></h1>
            </div>
        </div>

        <div class="nav-search">
            <div class="nav-search-category">
                <p>All</p>
                <img src="./assets/dropdown_icon.png" height="12" alt="">
            </div>
            <form action="searchAction.php" method="GET" id="form1" style="width:75px;height:10px; padding-top:none;">
    <input type="text" class="nav-search-input" name="query" placeholder="Search @ Rent Management System" style="width:310px; height:16px;">
    <button type="submit" style="position:relative; top:-37px; left:549px;">
        <img src="./assets/search_icon.png" class="nav-search-icon" alt="">
    </button>
</form>

        </div>

        <div class="nav-language">
            <img src="./assets/bill rs.jpg" width="25px" alt="">
            <a href="make_bill/make_bill.php"><p>Create Bills</p></a>
            <img src="./assets/dropdown_icon.png" width="8px" alt="">
        </div>

        <div class="nav-text">
            <p></p>
            <h1><a href="enq_comm/enq_comm.php">Save Contacts</a><img src="./assets/dropdown_icon.png" width:"8px" alt=""></h1>
        </div>
        <div class="nav-text">
            <p><a style="font-size: 16px; font-weight:bold;" href="reg_renter/reg_renter.php">Registration</a></p><br>
            <h1><a style="font-size: 16px; font-weight:bold;" href="rent_agr/ag_resc.php">Registration& Agreements </a></h1>
        </div>
        <a href="#" class="nav-cart"><img src="./assets/cart_icon.png" width="35px" alt="">
        <h4>Options</h4></a>
    </nav>

    <div class="nav-bottom">
        <div>
            
            <p><a href="other_functions/it_rules.php" target="_blank">IT-Rules Followed</a></p>&nbsp;&nbsp;&nbsp;
            <p><a href="other_functions/dev_details.php">Developer Contacts</a></p>&nbsp;&nbsp;&nbsp;
            <p></p>&nbsp;&nbsp;&nbsp;
            <p><a href="other_functions/ll_regist.php">Landlord Details</a></p>&nbsp;&nbsp;&nbsp;
            <p><a href="reset.php">Reset Password</a></p> &nbsp;&nbsp;&nbsp;
            <p><a href="logout.php">Logout</a></p>&nbsp;&nbsp;&nbsp;
        </div>
    </div>

    <div class="header-slider">
        <a href="#" class="control_prev">&#129144</a>
        <a href="#" class="control_next">&#129146</a>
        <ul>
            <img src="./assets/header1.jpg" class="header-img" alt="">
            <img src="./assets/header2.jpg" class="header-img" alt="">
            <img src="./assets/header3.jpg" class="header-img" alt="">
            <img src="./assets/header4.jpg" class="header-img" alt="">
            <img src="./assets/header5.jpg" class="header-img" alt="">
            <img src="./assets/header6.jpg" class="header-img" alt="">
        </ul>
    </div>

    <div class="box-row header-box">
        <div class="box-col">
            <h3>Online Payments</h3>
            <img src="./assets/imp-logo-online-payments.png" alt="">
            <a href="pay_online/ptm.php">UPI Method</a><br>
            <a href="pay_online/pay_records.php" target="_blank">Feed Details Manually</a>
        </div>
        <div class="box-col">
            <h3>Records & Reports</h3>
            <img src="./assets/imp-logo-records-reports.webp" alt="">
            <a href="see_records/see_records.php" target="_blank"><p>Click to Open Early Records</p></a><br>
                        <p><a href="backup_proc/backup.php" target="_blank">Export Reports (in pdf)</a></p>
        </div>
        <div class="box-col">
            <h3>List of Renters</h3>
            <img src="./assets/imp-logo-list-of-renters.png" alt="">
            <a href="rentr_list/rentr_list.php" target="_blank">Click To Proceed</a>
        </div>
        <div class="box-col">
            <h3>Rooms Available</h3>
            <img src="./assets/imp-logo-room-for-rent.jpg" alt="">
            <a href="rooms/roomlisting.php">View List of Available Rooms <br>+ Add Rooms <br>+Remove Rooms</a>
        </div>
    </div>
    <?php echo"{$user_data['user_name']} & password :{$user_data['password']}"?>
    <script src="script1.js"></script>
</body>
</html>