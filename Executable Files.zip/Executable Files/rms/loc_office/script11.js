document.getElementById('copyLink').addEventListener('click', function() {
    const link = "https://maps.app.goo.gl/UBr1LwznqEu6pGmL7";
    navigator.clipboard.writeText(link).then(function() {
        alert('Link copied to clipboard');
    }).catch(function(error) {
        console.error('Error copying text: ', error);
    });
});
