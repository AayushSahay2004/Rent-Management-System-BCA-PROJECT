<?php
// Database connection
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "rent_management_system";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Insert, Update, Delete operations
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['save'])) {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $address = $_POST['address'];
        $mobile = $_POST['mobile'];
        $id = $_POST['id'];

        if ($id) {
            // Update existing record
            $sql = "UPDATE enq_comm SET name='$name', age='$age', gender='$gender', address='$address', mobile='$mobile' WHERE id=$id";
        } else {
            // Insert new record
            $sql = "INSERT INTO enq_comm (name, age, gender, address,mobile) VALUES ('$name', '$age', '$gender', '$address','$mobile')";
        }

        $conn->query($sql);
    }

    if (isset($_POST['delete'])) {
        $id = $_POST['id'];
        $sql = "DELETE FROM enq_comm WHERE id=$id";
        $conn->query($sql);
    }

    if (isset($_POST['print'])) {
        $id = $_POST['id'];
        header("Location: print.php?id=$id");
        exit();
    }

    header("Location: enq_comm.php");
    exit();
}

// Retrieve data
$sql = "SELECT * FROM enq_comm";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Details_Enquiry</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            margin: 10px 0;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-actions {
            text-align: center;
            margin-top: 20px;
        }
        .form-actions button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .form-actions button[name="save"] {
            background-color: #28a745;
            color: #fff;
        }
        .form-actions button[name="save"]:hover {
            background-color: #218838;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f8f9fa;
        }
        td {
            background-color: #fff;
        }
        td button {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }
        td button[name="delete"] {
            background-color: #dc3545;
            color: #fff;
        }
        td button[name="delete"]:hover {
            background-color: #c82333;
        }
        td button[name="edit"] {
            background-color: #007bff;
            color: #fff;
        }
        td button[name="edit"]:hover {
            background-color: #0069d9;
        }
        .print-button {
            display: block;
            width: 150px;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-align: center;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .print-button:hover {
            background-color: #0069d9;
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
    <script>
        function editRecord(id, name, age, gender, address) {
            document.getElementById('id').value = id;
            document.getElementById('name').value = name;
            document.getElementById('age').value = age;
            document.getElementById('gender').value = gender;
            document.getElementById('address').value = address;
        }

        function printPDF() {
            const element = document.getElementById('records');
            html2pdf().from(element).save();
        }
    </script>
</head>
<body>
    <h1>Enquiry / Communication Details</h1>
    <a href="../index.php">Go to Homepage</a>
    <form method="post" action="enq_comm.php">
        <input type="hidden" id="id" name="id">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="age">Age:</label>
            <input type="number" id="age" name="age" required>
        </div>
        <div class="form-group">
            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>
        </div>
        <div class="form-group">
            <label for="mobile">Contact No.:</label>
            <input type="text" id="mobile" name="mobile" required>
        </div>
        <div class="form-actions">
            <button type="submit" name="save">Save</button>
        </div>
    </form>

    <div id="records">
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Contact no</th>
                <th>Actions</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['age']}</td>
                        <td>{$row['gender']}</td>
                        <td>{$row['address']}</td>
                        <td>{$row['mobile']}</td>
                        <td>
                            <button name=\"edit\" onclick=\"editRecord('{$row['id']}', '{$row['name']}', '{$row['age']}', '{$row['gender']}', '{$row['address']}')\">Edit</button>
                            <form method='post' action='enq_comm.php' style='display:inline;'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <button type='submit' name='delete'>Delete</button>
                            </form>
                            <form method='post' action='enq_comm.php' style='display:inline;'>
                                <input type='hidden' name='id' value='{$row['id']}'>
                                <button type='submit' name='print'>Print</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </table>
    </div>
    <button class="print-button" onclick="printPDF()">Print to PDF</button>
</body>
</html>

