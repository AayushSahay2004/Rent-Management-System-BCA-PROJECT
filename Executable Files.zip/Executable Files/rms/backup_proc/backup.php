<?php
// Function to generate random 6-character UPI ID
function generateUPIID() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $upi_id = 'UPI';
    for ($i = 0; $i < 6; $i++) {
        $upi_id .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $upi_id;
}

// Handling form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verify the PIN
    $pin = $_POST['pin'];
    if ($pin != '55555') {
        echo "<script>alert('Incorrect PIN');</script>";
        exit();
    }

    // Set up the backup directory on the Desktop
    $backup_dir = getenv("HOMEDRIVE") . getenv("HOMEPATH") . '\Desktop\Backup_' . date('Ymd');
    if (!file_exists($backup_dir)) {
        mkdir($backup_dir, 0777, true);
    }

    // Function to copy directory
    function copyDirectory($src, $dst) {
        $dir = opendir($src);
        @mkdir($dst);
        while (false !== ($file = readdir($dir))) {
            if (($file != '.') && ($file != '..')) {
                if (is_dir($src . '/' . $file)) {
                    copyDirectory($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }

    // Copy the stores directory to the backup folder
    $source_dir = 'C:/xampp/htdocs/rms/rent_agr/stores';
    $destination_dir = $backup_dir . '/stores';
    copyDirectory($source_dir, $destination_dir);

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'rent_management_system');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Function to fetch data from a table and return as HTML
    function fetchTableData($conn, $tableName, $fields) {
        $sql = "SELECT " . implode(", ", $fields) . " FROM " . $tableName;
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $html = "<h2>$tableName</h2>";
            $html .= "<table border='1'><tr>";
            foreach ($fields as $field) {
                $html .= "<th>$field</th>";
            }
            $html .= "</tr>";

            while ($row = $result->fetch_assoc()) {
                $html .= "<tr>";
                foreach ($fields as $field) {
                    $html .= "<td>" . $row[$field] . "</td>";
                }
                $html .= "</tr>";
            }
            $html .= "</table>";
            return $html;
        } else {
            return "<h2>$tableName</h2><p>No records found</p>";
        }
    }

    // Fetch data from each table
    $users_fields = ['id', 'user_id', 'user_name', 'password', 'productkey', 'date'];
    $reg_renter_fields = ['id', 'name', 'age', 'gender', 'datereg', 'aadhar', 'mobile', 'address', 'roomNo', 'price'];
    $entries_fields = ['id', 'room_id', 'photo_path', 'sign_path', 'aadhar_path', 'created_at'];
    $enq_comm_fields = ['id', 'name', 'age', 'gender', 'address', 'mobile', 'time_of_saving'];
    $bill_details_fields = ['id', 'renter_id', 'month', 'year', 'due_date', 'room_rent', 'units_used', 'electric_bill', 'advance_paid', 'amount_dues', 'miscellaneous', 'total_amount', 'created_at'];
    $payment_status_fields = ['id', 'renter_id', 'date_pay', 'month', 'amount', 'pay_status', 'description'];

    $data_html = "";
    $data_html .= fetchTableData($conn, 'users', $users_fields);
    $data_html .= fetchTableData($conn, 'reg_renter', $reg_renter_fields);
    $data_html .= fetchTableData($conn, 'entries', $entries_fields);
    $data_html .= fetchTableData($conn, 'enq_comm', $enq_comm_fields);
    $data_html .= fetchTableData($conn, 'bill_details', $bill_details_fields);
    $data_html .= fetchTableData($conn, 'payment_status', $payment_status_fields);

    // Close connection
    $conn->close();

    // Save the data HTML to a file
    $data_file = $backup_dir . '/data.html';
    file_put_contents($data_file, $data_html);

    echo "<script>alert('Backup created successfully');</script>";
    echo "<script>window.location.href='backup.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup Module</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: auto;
            overflow: hidden;
        }
        .section {
            margin: 20px 0;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .section h2 {
            margin-top: 0;
            color: #00b3b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #00b3b3;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .backup-button {
            background-color: #0070ba;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .backup-button:hover {
            background-color: #005f9e;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="section">
            <h2>Data Backup</h2>
            <button class="backup-button" onclick="createBackup()">Create Backup</button>
            <div id="data-container">
                <!-- Data will be loaded here by JavaScript -->
            </div>
        </div>
    </div>

    <script>
        function createBackup() {
            var pin = prompt("Enter Pin:");
            if (pin !== "55555") {
                alert("Incorrect PIN");
                return;
            }
            document.forms["backupForm"].submit();
        }
    </script>

    <form id="backupForm" method="POST" style="display: none;">
        <input type="hidden" name="pin" value="55555">
    </form>
</body>
</html>
