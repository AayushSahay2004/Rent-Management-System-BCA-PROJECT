<?php
session_start();
include("connection.php");
include("functions.php");
$user_data=check_login($con);
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the search query
$searchQuery = isset($_GET['query']) ? $_GET['query'] : '';

// Sanitize the input
$searchQuery = $conn->real_escape_string($searchQuery);

// SQL query to search by roomNo or partial name match
$sql = "SELECT * FROM reg_renter WHERE roomNo = '$searchQuery' OR name LIKE '%$searchQuery%'";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
    </style>
</head>
<body>
    <h1>Search Results</h1>
    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Serial No</th>
                <th>Date Registered</th>
                <th>Name</th>
                <th>Room No</th>
                <th>Price</th>
            </tr>
            <?php 
            $serialNo = 1;
            while($row = $result->fetch_assoc()): 
            ?>
                <tr>
                    <td><?php echo $serialNo++; ?></td>
                    <td><?php echo $row['datereg']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['roomNo']; ?></td>
                    <td><?php echo $row['price']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No results found for "<?php echo htmlspecialchars($searchQuery); ?>"</p>
    <?php endif; ?>
    <?php $conn->close(); ?>
</body>
</html>
