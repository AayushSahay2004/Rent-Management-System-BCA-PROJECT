<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
$server="localhost";
$pass="";
$user="root";
$dbname="rent_management_system";
$conn=mysqli_connect($server,$user,$pass,$dbname);
$sql="select * from file_upload";
$result=$conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Listing</title>
    <link rel="stylesheet" href="roomlist.css">
</head>
<body>
    <nav><a href="../index.php">Go to Home Page</a><br>
        <a href="../logout.php">Click to logout</a><br>
        <a href="addrooms.php">Add Rooms</a><br>
        <a href="remove.php">Remove Rooms</a><br>
    </nav>
    <h1>List of Available Rooms</h1>
    <table>
        <thead>
            <tr>
                <th>Serial No.</th>
                <th>Room ID</th>
                <th>Room Name</th>
                <th>Status</th>
                <th>Room Layouts</th>
            </tr>
        </thead>
        <tbody>
        <?php
        $count = 1;
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $count . "</td>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['roomname'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td><button class='openPdfBtn' data-room='" . $count . "'>View Rooms</button></td>";
                echo "</tr>";
                $count++;
            }
        } else {
            echo "<tr><td colspan=5>No records found</td></tr>";
        }
        ?>
        </tbody>
    </table>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const layoutButtons = document.querySelectorAll('.openPdfBtn');

            layoutButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const roomNumber = button.getAttribute('data-room');
                    window.open(`uploads/room${roomNumber}.pdf`, '_blank');
                });
            });
        });
    </script>
</body>
</html>
