<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
$server="localhost";
$pass="";
$user="root";
$dbname="rent_management_system";
$conn=mysqli_connect($server,$user,$pass,$dbname);
$sql="select * from file_upload";
$result=$conn->query($sql);
$delId=$_POST['idtodelete'];
$sql1 = "DELETE FROM file_upload WHERE id = ?";

    if ($stmt = $conn->prepare($sql1)) {
        $stmt->bind_param("i", $delId);
    }
    if ($stmt->execute()) {
        echo "Record deleted successfully";
 
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    
    $stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Remove Rooms</title>
    <link rel="stylesheet" href="roomlist.css">
</head>
<body>
    <nav><a href="roomlisting.php">Go to Home Page</a><br>
        <a href="../logout.php">Click to logout</a><br>
        <a href="addrooms.php">Add Rooms</a><br>
        <a href="delete.php">Remove Rooms</a><br>
    </nav>
    <h1>List of Available Rooms</h1>
    <table>
        <thead>
            <tr>
                <th>serial No.</th>
                <th>room id </th>
                <th>Rooms Name</th>
                <th>Status</th>
                <th>Room Layouts</th>
  
            </tr>
        </thead>
        <tbody>
        <?php
        $count=1;
        if($result->num_rows>0){
            while($row=$result->fetch_assoc()){
                echo"<tr>";
                echo"<td>".$count."</td>";
                echo"<td>".$row['id']."</td>";
                echo"<td>".$row['roomname']."</td>";
                echo"<td>".$row['status']."</td>";
                echo"<td><button id='openPdfBtn'>Open PDF</button></td>";
                echo"</tr>";
                $count++;
            }
        }else{
            echo"<tr><td colspan=5>No records found</td></tr>";
        }
        ?>
            
        </tbody>
    </table>
        <form action="remove.php" method="post">
            <h1>Delete Rooms</h1>
            <label for="">Enter the room id to Delete the room</label>
            <input type="number" name="idtodelete" id="">
            <button type="submit" name='submit'>Delete</button>
        </form>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
    const layoutButtons = document.querySelectorAll('.layout-btn');

    layoutButtons.forEach(button => {
        button.addEventListener('click', () => {
            const roomNumber = button.getAttribute('data-room');
            alert(`Displaying layout for Room ${roomNumber}`);
            // Here you can implement more complex logic, such as fetching and displaying room layout details.
        });
    });
});

        document.getElementById('openPdfBtn').onclick = function() {
            window.open('uploads/pdf.pdf', '_blank');
        };

    </script>
</body>
</html>
