<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
$server="localhost";
$pass="";
$user="root";
$dbname="rent_management_system";
$conn=mysqli_connect($server,$user,$pass,$dbname);
$roomName=$_POST['roomname'];
$roomStatus=$_POST['roomstatus'];
if(isset($_POST['submit'])){
$targetDir='uploads/';
$targetFile=$targetDir.basename($_FILES['pdfFile']['name']);
$fileType=strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));
if($fileType!="pdf" || $_FILES['pdfFile']['size']>6000000){
    echo"only pdf + 2mb less than";
}
else{
    //move it to the uploads folder
    if(move_uploaded_file($_FILES['pdfFile']['tmp_name'],$targetFile)){
        $filename=$_FILES['pdfFile']['name'];
        $folder_path=$targetDir;
        $timestamp=date('Y-m-d H:i:s');
        $sql="Insert into file_upload(filename,roomname,status,folder_path,timestamp)
                values('$filename','$roomName','$roomStatus','$folder_path','$timestamp')";
        if($conn->query($sql)==TRUE){
            echo"success";
        }   
        else{
            echo"Error".$sql."<br>".$conn->error;
        }     
    }
    else{
        echo"Error upload!";
    }
}
}
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Room Details</title>
    <link rel="stylesheet" href="roomlist.css">
</head>
<body>
    <h1>Add Rooms Details</h1><br>
    <form action="addrooms.php" method="post" enctype="multipart/form-data">
        <label for="">Name of Room :</label>
        <input type="text" name="roomname"><br><br>
        <label for="">Status(Free/Occupied):</label>
        <input type="text" name="roomstatus"><br><br>
        <label for="">Interiors and Layout(.pdf)</label>
        <input type="file" name='pdfFile' id=pdfFile>
        <button type="submit" name="submit">Submit</button>
    </form>
    <a href="roomlisting.php">Go to Room Listing</a>
</body>
</html>