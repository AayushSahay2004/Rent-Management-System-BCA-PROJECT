<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $renter_id = $_POST['renter'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $due_date = $_POST['due_date'];
    $room_rent = $_POST['room_rent'];
    $units_used = $_POST['units_used'];
    $electric_bill = $_POST['electric_bill'];
    $advance_paid = $_POST['advance_paid'];
    $amount_dues = $_POST['amount_dues'];
    $miscellaneous = $_POST['miscellaneous'];
    $total_amount = $_POST['total_amount'];

    // Insert into bill_details table
    $sql = "INSERT INTO bill_details (renter_id, month, year, due_date, room_rent, units_used, electric_bill, advance_paid, amount_dues, miscellaneous, total_amount) 
            VALUES ('$renter_id', '$month', '$year', '$due_date', '$room_rent', '$units_used', '$electric_bill', '$advance_paid', '$amount_dues', '" . json_encode($miscellaneous) . "', '$total_amount')";

    if ($conn->query($sql) === TRUE) {
        echo "Bill details saved successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
