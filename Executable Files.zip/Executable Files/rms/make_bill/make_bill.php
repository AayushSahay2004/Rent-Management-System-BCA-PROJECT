<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Rent Bill</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        h1 {
            text-align: center;
            background-color: #4CAF50;
            color: white;
            padding: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        .print-button {
            background-color: #008CBA;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #007B9A;
        }
        .add-row {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        }
        .add-row:hover {
            background-color: #45a049;
        }
        .message {
            margin-top: 10px;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Room Rent Bill</h1>
        <form method="post" action="bill_logic.php">
            <div class="form-group">
                <label for="renter">Tenant Name:</label>
                <select id="renter" name="renter" onchange="fetchRoomNo()">
                    <option value="">Select Tenant</option>
                    <?php
                    // Database connection
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $dbname = "rent_management_system";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch data from the reg_renter table
                    $sql = "SELECT id, name, roomNo FROM reg_renter";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row["id"] . "' data-roomNo='" . $row["roomNo"] . "'>" . $row["name"] . "</option>";
                        }
                    }

                    $conn->close();
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Room No: <span id="roomNoDisplay"></span></label>
            </div>
            <div class="form-group">
                <label for="month">Month:</label>
                <select id="month" name="month">
                    <?php
                    for ($i = 1; $i <= 12; $i++) {
                        $month = date("F", mktime(0, 0, 0, $i, 10));
                        echo "<option value='$month'>$month</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="year">Year:</label>
                <select id="year" name="year">
                    <?php
                    $currentYear = date("Y");
                    for ($i = $currentYear; $i <= $currentYear + 5; $i++) {
                        echo "<option value='$i'>$i</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="due_date">Rent To be cleared by date:</label>
                <input type="date" id="due_date" name="due_date" required>
            </div>
            <div class="form-group">
                <label for="room_rent">Room Rent of the Renter:</label>
                <input type="text" id="room_rent" name="room_rent" oninput="calculateTotal()" required>
            </div>
            <div class="form-group">
                <label id="electric_meter">Electric Bill of room: <span id="electricRoomNo"></span></label>
                <input type="text" id="units_used" name="units_used" oninput="calculateElectricBill()" required>
            </div>
            <div class="form-group">
                <label for="electric_bill">Electric Bill:</label>
                <input type="text" id="electric_bill" name="electric_bill" readonly required>
            </div>
            <div class="form-group">
                <label for="advance_paid">Amount paid in advance:</label>
                <input type="text" id="advance_paid" name="advance_paid" oninput="calculateTotal()" required>
            </div>
            <div class="form-group">
                <label for="amount_dues">Amount dues:</label>
                <input type="text" id="amount_dues" name="amount_dues" oninput="calculateTotal()" required>
            </div>
            <table id="miscTable">
                <thead>
                    <tr>
                        <th>Serial No</th>
                        <th>Miscellaneous charges for</th>
                        <th>Amount</th>
                        <th><button type="button" class="add-row" onclick="addRow()">+</button></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td><input type="text" name="miscellaneous[0][description]" required></td>
                        <td><input type="text" name="miscellaneous[0][amount]" oninput="calculateTotal()" required></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <label for="total_amount">Total Amount Payable:</label>
                <input type="text" id="total_amount" name="total_amount" readonly required>
            </div>
            <div class="form-group">
                <p class="message">* Room agreement Advance is never to be deducted.</p>
            </div>
            <button type="submit">Save Bill</button>
            <button type="button" class="print-button" onclick="printBill()">Print Bill</button>
        </form>
    </div>

    <script>
        function fetchRoomNo() {
            var renterSelect = document.getElementById("renter");
            var selectedOption = renterSelect.options[renterSelect.selectedIndex];
            var roomNo = selectedOption.getAttribute("data-roomNo");
            document.getElementById("roomNoDisplay").innerText = roomNo;
            document.getElementById("electricRoomNo").innerText = roomNo;
        }

        function calculateElectricBill() {
            var unitsUsed = document.getElementById("units_used").value;
            var electricBill = unitsUsed * 9; // Adjust this calculation based on your billing rate per unit
            document.getElementById("electric_bill").value = "₹" + electricBill.toFixed(2);
            calculateTotal();
        }

        function addRow() {
            var table = document.getElementById("miscTable").getElementsByTagName('tbody')[0];
            var rowCount = table.rows.length;
            var row = table.insertRow(rowCount);

            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            var cell3 = row.insertCell(2);
            var cell4 = row.insertCell(3);

            cell1.innerHTML = rowCount + 1;
            cell2.innerHTML = '<input type="text" name="miscellaneous[' + rowCount + '][description]" required>';
            cell3.innerHTML = '<input type="text" name="miscellaneous[' + rowCount + '][amount]" oninput="calculateTotal()" required>';
            cell4.innerHTML = '';
        }

        function calculateTotal() {
            var roomRent = parseFloat(document.getElementById("room_rent").value) || 0;
            var electricBill = parseFloat(document.getElementById("electric_bill").value.substring(1)) || 0;
            var advancePaid = parseFloat(document.getElementById("advance_paid").value) || 0;
            var amountDues = parseFloat(document.getElementById("amount_dues").value) || 0;

            var miscTable = document.getElementById("miscTable").getElementsByTagName('tbody')[0];
            var rows = miscTable.rows;
            var miscTotal = 0;
            for (var i = 0; i < rows.length; i++) {
                var amount = parseFloat(rows[i].cells[2].getElementsByTagName('input')[0].value) || 0;
                miscTotal += amount;
            }

            var totalAmount = roomRent + electricBill + amountDues + miscTotal - advancePaid;
            document.getElementById("total_amount").value = totalAmount.toFixed(2);
        }

        function printBill() {
            window.print();
        }
    </script>
    <h2><a href="../index.php">Go to Main Page</a></h2>
</body>
</html>
