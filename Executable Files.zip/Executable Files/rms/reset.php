<?php
session_start();
include("connection.php");
include("functions.php");
if($_SERVER['REQUEST_METHOD']=="POST"){
    $user_name=$_POST['user_name'];
    $prokey=$_POST['prokey'];
    $new_password = $_POST['new_password'];
    if(!empty($user_name) && !empty($prokey) && !is_numeric($user_name)){
        // Read from the database
        $query= "SELECT * FROM users WHERE user_name='$user_name' LIMIT 1";
        $result1 = mysqli_query($con, $query);
        
        if ($result1) {
            if ($result1 && mysqli_num_rows($result1) > 0) {
                $user_data = mysqli_fetch_assoc($result1);
               
                $update_query = "UPDATE users SET password='$new_password' WHERE user_name='$user_name' and productkey='$prokey'";
                $update_result = mysqli_query($con, $update_query);
                
                if ($update_result) {
                    // Password reset successful
                    echo "<script>alert('Password reset successful'); window.location.href = 'login.php';</script>";
                } else {
                    // Password reset failed
                    echo "<script>alert('Password reset failed'); window.location.href = 'login.php';</script>";
                }
                
            } else {
                // User not found
                echo "<script>alert('User not found'); window.location.href = 'login.php';</script>";
            }
        } else {
            // Query failed
            echo "<script>alert('Database query failed'); window.location.href = 'login.php';</script>";
        }
        
        die;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset PWD</title>
    <style>
        *{margin:0; padding:0; box-sizing:border-box;}
        body{min-height: 100vh; background:#eee; display:flex; font-family: sans-serif;}
        .container{margin:auto;width:500px; max-width:90%;}
        .container form{width:100%; height:100%; padding:20px; background:white;
        border-radius:4px;box-shadow: 0 8px 16px rgba(0,0,0,0.3); }
        .container form h1{text-align:center; margin-bottom: 24px; color:#222;}
        .container form .form-control{width:100%; height:40px; background:white; border-radius:4px; border:1px solid silver; margin:10px 0
         18px 0; padding: 0 10px; }
         .container form .btn{margin-left:50%; transform:translate(-50%); width:120px;
        height:34px; border:none; outline:none; background:#222; cursor:pointer; font-size: 16px; text-transform:uppercase; color:white; border-radius: 4px; transition: 0.3s;}
        .container form .btn:hover{opacity:0.7;}
        #btn1 a{text-decoration: none; color: #eee;}
        #btn1{position:relative;
        top:-34px;
          left:140px;
        font-size: 12px;}
        #btn2 a{text-decoration: none; color: #eee;}
        #btn2{position:relative;
        top:-68px;
          left:-140px;
        font-size: 12px;}

        #logo{width:626px; position: relative; top:80px; height:480px; left:35px;}

    </style>
</head>
<body>
    <?php
if (isset($_GET['logout']) && $_GET['logout'] == 'success') {
        echo "<script>alert('User was logged out successfully');</script>";
    } else {
        echo "<script>console.log('Logout parameter not set or incorrect');</script>";
    }
?>
    <img id="logo"src="assets_login/login-page-img.jpg" alt="">
    <div class="container">

            <form action="reset.php" method="post">
                <h1>Reset Password</h1>
                <div class="formgroup">
                    <label for="">Email</label>
                    <input type="email" class="form-control" name="user_name" id="email" required>
                </div>
                <div class="formgroup">
                    <label for="">Product Key</label>
                    <input type="text" class="form-control" name="prokey" id="prokey" required>
                </div>
                <div class="formgroup">
                    <label for="">New Password</label>
                    <input type="password" class="form-control" name="new_password" id="password" required>
                </div>
                <input class="btn" type="submit" value="RESET">
                <button id="btn1" class="btn"><a href="login.php">Login</a></button>
                <button id="btn2" class="btn"><a href="signup.php">Register User</a></button> 
            </form>
           
        
    </div>
</body>
</html>