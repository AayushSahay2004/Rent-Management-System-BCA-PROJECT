<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            text-align: center;
        }
        .container img {
            border-radius: 10px;
        }
        .details {
            margin-top: 20px;
        }
        .details h1 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .details p {
            margin: 5px 0;
            font-size: 18px;
            color: #555;
        }
        .print-button {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #0056b3;
        }
        #idc{height:315px;}
    </style>
</head>
<body>
    <div class="container">
        <img src="othr_func_resc/developer_belongs_to_univ.jpg" alt="University">
        <div class="details">
            <h1>Aayush Sahay</h1>
            <p>Student of: Indian Institute of Business Management, Patna</p>
            <p>Course: BCA</p>
            <p>Roll No.: AKU/31</p>
            <p>Session: 2021-2024</p>
            <p>Enrollment No.: 21303334049</p>
        </div>
        <img src="othr_func_resc/picture_developer.jpeg" alt="Developer" id="idc"><br>
        <button class="print-button" onclick="window.print()">Print Details</button>
    </div>
</body>
</html>
