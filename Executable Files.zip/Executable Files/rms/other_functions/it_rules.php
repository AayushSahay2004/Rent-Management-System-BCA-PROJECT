<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Rules</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #50b3a2;
            color: #fff;
            padding-top: 30px;
            min-height: 70px;
            border-bottom: #e8491d 3px solid;
        }
        header a {
            color: #fff;
            text-decoration: none;
            text-transform: uppercase;
            font-size: 16px;
        }
        header ul {
            padding: 0;
            list-style: none;
        }
        header li {
            float: right;
            display: inline;
            padding: 0 20px 0 20px;
        }
        header .highlight, header .current a {
            color: #e8491d;
            font-weight: bold;
        }
        header #branding {
            float: left;
        }
        header #branding h1 {
            margin: 0;
        }
        .button {
            height: 40px;
            background: #50b3a2;
            border: none;
            padding: 0 20px;
            color: #fff;
            text-transform: uppercase;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
        }
        .content {
            padding: 20px;
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .content h2 {
            border-bottom: 2px solid #e8491d;
            padding-bottom: 10px;
        }
        .content ul {
            padding: 0;
            list-style: none;
        }
        .content li {
            margin-bottom: 10px;
            padding-left: 20px;
            position: relative;
        }
        .content li:before {
            content: "✔";
            position: absolute;
            left: 0;
            color: #50b3a2;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div id="branding">
                <h1>IT Rules & Best Practices</h1>
            </div>
        </div>
    </header>
    <div class="container">
        <div class="content">
            <h2>Security Measures</h2>
            <ul>
                <li>Data Validation and Sanitization</li>
                <li>Authentication and Authorization</li>
                <li>Secure Password Storage</li>
                <li>Session Management</li>
                <li>Encryption</li>
                <li>Prevent Cross-Site Scripting (XSS)</li>
            </ul>

            <h2>Data Integrity</h2>
            <ul>
                <li>Database Normalization</li>
                <li>Transactions</li>
            </ul>

            <h2>Performance Optimization</h2>
            <ul>
                <li>Efficient Queries</li>
                <li>Caching</li>
                <li>Pagination</li>
            </ul>

            <h2>Error Handling</h2>
            <ul>
                <li>Logging</li>
                <li>User-Friendly Messages</li>
            </ul>

            <h2>Scalability</h2>
            <ul>
                <li>Modular Code</li>
                <li>Database Design</li>
            </ul>

            <h2>Compliance and Data Protection</h2>
            <ul>
                <li>GDPR Compliance</li>
                <li>Audit Trails</li>
            </ul>

            <h2>Backup and Recovery</h2>
            <ul>
                <li>Regular Backups</li>
                <li>Disaster Recovery Plan</li>
            </ul>

            <h2>Usability</h2>
            <ul>
                <li>User Interface Design</li>
                <li>Accessibility</li>
            </ul>

            <h2>Documentation and Testing</h2>
            <ul>
                <li>Comprehensive Documentation</li>
                <li>Testing</li>
            </ul>

            <h2>Compliance with Coding Standards</h2>
            <ul>
                <li>Coding Standards</li>
            </ul>

            <h2>Version Control</h2>
            <ul>
                <li>Source Control</li>
            </ul>
        </div>
        <button class="button" onclick="printPage()">Go Through Our IT Considerations</button>
    </div>

    <script>
        function printPage() {
            window.print();
        }
    </script>
</body>
</html>
