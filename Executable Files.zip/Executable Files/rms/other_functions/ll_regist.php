<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Registration Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            text-align: center;
        }
        .container img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .details {
            margin-top: 20px;
        }
        .details h1 {
            margin: 0;
            font-size: 28px;
            color: #333;
        }
        .details p {
            margin: 5px 0;
            font-size: 18px;
            color: #555;
        }
        .print-button {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Company Registration Details</h1>
        <img src="othr_func_resc/company_name.jpg" alt="University">
        <div class="details">
            <p><strong>Company Name:</strong> ABC Apartments and Housings PVT LTD</p>
            <p><strong>Owner:</strong> Mr. ABC Kumar</p>
            <p><strong>Registered In:</strong> Bihar, India</p>
            <p><strong>Year of Registration:</strong> 2008</p>
            <p><strong>Trademark Purchased:</strong> 2010</p>
        </div>
        <img src="othr_func_resc/trademark.jpg" alt="Developer">
        <button class="print-button" onclick="window.print()">Print Details</button>
    </div>
</body>
</html>
