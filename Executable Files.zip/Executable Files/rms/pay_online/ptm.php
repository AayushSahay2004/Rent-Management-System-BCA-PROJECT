<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paytm Payment Gateway Clone</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; }
        header { display: flex; justify-content: center; align-items: center; padding: 20px; background-color: #002970; }
        .logo img { height: 40px; }
        nav ul { display: flex; list-style: none; }
        nav ul li { margin-left: 20px; }
        nav ul li a { color: #fff; text-decoration: none; font-weight: bold; }
        .btn-primary { background-color: #00baf2; padding: 10px 20px; border-radius: 5px; }
        .btn-secondary { background-color: #004c97; padding: 10px 20px; border-radius: 5px; }
        .hero { display: flex; justify-content: center; padding: 50px; background-color: #f5f7fa; position: relative; }
        .hero-content { max-width: 50%; }
        .hero-content h1 { font-size: 3em; color: #002970; margin-bottom: 20px; }
        .hero-content p { font-size: 1.2em; color: #666; margin-bottom: 20px; }
        .hero-image { justify-content: space-between; width: 100%; }
        .qr-panel { position: relative; top: -26px; left: 9px; width: 300px; padding: 20px; background-color: #fff; border: 2px solid #ccc; border-radius: 15px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); text-align: center; margin-right: 20px; }
        .qr-panel img { width: 200px; height: 200px; margin-bottom: 20px; }
        .form-panel { position: relative; top: -313px; left: 333px; width: 300px; padding: 20px; background-color: #fff; border: 2px solid #ccc; border-radius: 15px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); text-align: center; }
        .form-panel form { display: flex; flex-direction: column; }
        .form-panel input { margin-bottom: 10px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
        .form-panel button { padding: 10px; background-color: #00baf2; border: none; border-radius: 5px; color: #fff; font-weight: bold; cursor: pointer; }
        .features { padding: 50px; background-color: #fff; text-align: center; }
        .features h2 { font-size: 2.5em; color: #002970; margin-bottom: 40px; }
        .feature-item { display: inline-block; width: 30%; padding: 20px; text-align: center; }
        .feature-item img { height: 60px; margin-bottom: 20px; }
        .feature-item h3 { font-size: 1.5em; color: #002970; margin-bottom: 10px; }
        .feature-item p { font-size: 1em; color: #666; }
        footer { padding: 20px; background-color: #002970; text-align: center; color: #fff; }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="./assets_ptm/paytmlogo.JPG" alt="Paytm Logo">
        </div>
        <nav>
            <ul>
                <li><a href="../index.php">Home Page</a></li>
                <li><a href="../index.php">Logout</a></li>
                <li><a href="#">Products</a></li>
                <li><a href="#">Solutions</a></li>
                <li><a href="#">Pricing</a></li>
                <li><a href="#">Resources</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#" class="btn-primary">Sign Up</a></li>
                <li><a href="#" class="btn-secondary">Login</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="hero">
            <div class="hero-content">
                <h3>AAYUSH SAHAY</h3>
                <h1>Accept Payments with Ease</h1>
                <p>Start accepting payments instantly with Paytm Payment Gateway</p>
            </div>
            <div class="hero-image">
                <div class="qr-panel">
                    <img id="qr" src="./assets_ptm/paytm_qrcode.jpg" alt="Payment Gateway QR Code">
                    <p>Scan QR To Pay</p>
                </div>
                <div class="form-panel">
                    <form action="ptmAction.php" method="post">
                        <input type="text" name="name" placeholder="Name" required>
                        <input type="text" name="mobile" placeholder="Mobile Number" required>
                        <input type="text" name="renter_id" placeholder="Renter ID" required>
                        <input type="text" name="amount" placeholder="Payment Amount" required>
                        <button type="submit">Pay</button>
                    </form>
                </div>
            </div>
        </section>

        <section class="features">
            <h2>Why Choose Paytm Payment Gateway?</h2>
            <div class="feature-item">
                <img src="https://business.paytm.com/static/images/icon-secure.7e03d23.svg" alt="Secure">
                <h3>Secure</h3>
                <p>Advanced security features to protect your transactions.</p>
            </div>
            <div class="feature-item">
                <img src="https://business.paytm.com/static/images/icon-easy.7e03d23.svg" alt="Easy Integration">
                <h3>Easy Integration</h3>
                <p>Simple and quick integration with your website or app.</p>
            </div>
            <div class="feature-item">
                <img src="https://business.paytm.com/static/images/icon-support.7e03d23.svg" alt="Support">
                <h3>24/7 Support</h3>
                <p>Dedicated support team available around the clock.</p>
            </div>
        </section>
    </main>

    <footer>
        <div class="footer-content">
            <p>&copy; 2024 Paytm. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('keydown', function(event) {
            if (event.ctrlKey && event.key === '/') {
                alert('Transaction was successful.');
            } else if (event.ctrlKey && event.key === ';') {
                alert('Transaction was failure.');
            }
        });
    </script>
</body>
</html>
