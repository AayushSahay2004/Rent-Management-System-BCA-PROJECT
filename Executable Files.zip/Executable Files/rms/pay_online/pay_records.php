<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        .section {
            margin: 20px 0;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .section h2 {
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .form-container {
            margin-top: 20px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }
        .form-container label, .form-container input {
            display: block;
            margin-bottom: 10px;
        }
        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="date"] {
            width: calc(100% - 22px); /* Adjusted width for inputs */
            padding: 8px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }
        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }
        .delete-btn {
            padding: 5px 10px;
            background-color: #f44336;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            margin-left: 10px;
        }
        .delete-btn:hover {
            background-color: #da190b;
        }
    </style>
    <script>
        function confirmDelete(id) {
            var pin = prompt("Enter PIN to delete this record:");
            if (pin === "55555") {
                window.location.href = "delete_record.php?id=" + id;
            } else {
                alert("Incorrect PIN. Record not deleted.");
            }
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="section">
            <h2>Add Payment Record</h2>
            <div class="form-container">
                <form action="pay_records.php" method="post">
                    <label for="date_pay">Date of Payment:</label>
                    <input type="date" id="date_pay" name="date_pay" required>
                    
                    <label for="renter_id">Renter ID:</label>
                    <input type="text" id="renter_id" name="renter_id" required>
                    
                    <label for="month">Month:</label>
                    <input type="text" id="month" name="month" required>
                    
                    <label for="amount">Amount:</label>
                    <input type="number" id="amount" name="amount" required>
                    
                    <label for="pay_status">Status:</label>
                    <input type="text" id="pay_status" name="pay_status" required>
                    
                    <label for="description">Payment Description:</label>
                    <input type="text" id="description" name="description" required>
                    
                    <input type="submit" value="Submit">
                </form>
            </div>
        </div>
        
        <div class="section">
            <h2>Payment Records</h2>
            <table>
                <tr>
                    <th>Renter ID</th>
                    <th>Date of Payment</th>
                    <th>Month</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Payment Description</th>
                    <th>Action</th>
                </tr>
                <?php
                // Database connection
                $conn = new mysqli('localhost', 'root', '', 'rent_management_system');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Insert record into payment_status table
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $date_pay = $_POST['date_pay'];
                    $renter_id = $_POST['renter_id'];
                    $month = $_POST['month'];
                    $amount = $_POST['amount'];
                    $pay_status = $_POST['pay_status'];
                    $description = $_POST['description'];

                    $sql = "INSERT INTO payment_status (renter_id, date_pay, month, amount, pay_status, description)
                            VALUES ('$renter_id', '$date_pay', '$month', '$amount', '$pay_status', '$description')";

                    if ($conn->query($sql) === TRUE) {
                        echo "<meta http-equiv='refresh' content='0'>";
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }

                // Fetch data from payment_status table
                $sql = "SELECT * FROM payment_status";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['renter_id']}</td>
                                <td>{$row['date_pay']}</td>
                                <td>{$row['month']}</td>
                                <td>{$row['amount']}</td>
                                <td>{$row['pay_status']}</td>
                                <td>{$row['description']}</td>
                                <td><button class='delete-btn' onclick='confirmDelete({$row['id']})'>Delete</button></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No records found</td></tr>";
                }

                // Close connection
                $conn->close();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
