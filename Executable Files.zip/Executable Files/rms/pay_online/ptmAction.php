<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Transaction</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            margin: auto;
            overflow: hidden;
        }
        .section {
            margin: 20px 0;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .section h2 {
            margin-top: 0;
            color: #00b3b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #00b3b3;
            color: #fff;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .print-button {
            background-color: #0070ba;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .print-button:hover {
            background-color: #005f9e;
        }
    </style>
    <script>
        function printPage() {
            window.print();
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="section">
            <h2>Payment Transaction Details</h2>
            <?php
            // Function to generate random 6-character UPI ID
            function generateUPIID() {
                $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                $upi_id = 'UPI';
                for ($i = 0; $i < 6; $i++) {
                    $upi_id .= $characters[rand(0, strlen($characters) - 1)];
                }
                return $upi_id;
            }

            // Handling form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Extract form data
                $name = $_POST['name'];
                $mobile = $_POST['mobile'];
                $renter_id = $_POST['renter_id'];
                $amount = $_POST['amount'];
                
                // Generate random UPI ID
                $upi_id = generateUPIID();
                
                // Current date and time
                $date_pay = date("Y-m-d H:i:s");

                // Database connection
                $conn = new mysqli('localhost', 'root', '', 'rent_management_system');

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Prepare SQL statement for inserting data into payment_status table
                $sql = "INSERT INTO payment_status (renter_id, date_pay, month, amount, pay_status, description)
                        VALUES ('$renter_id', '$date_pay', '', '$amount', 'online_trxn_success', '$name$mobile$upi_id')";

                // Execute SQL statement
                if ($conn->query($sql) === TRUE) {
                    echo "<script>alert('Transaction successful. UPI ID: $upi_id');</script>";
                } else {
                    echo "<script>alert('Transaction failed. Error: " . $conn->error . "');</script>";
                }

                // Close connection
                $conn->close();

                // Display transaction details
                echo "
                <table>
                    <tr>
                        <th>Name</th>
                        <td>$name</td>
                    </tr>
                    <tr>
                        <th>Mobile</th>
                        <td>$mobile</td>
                    </tr>
                    <tr>
                        <th>Renter ID</th>
                        <td>$renter_id</td>
                    </tr>
                    <tr>
                        <th>Amount</th>
                        <td>$amount</td>
                    </tr>
                    <tr>
                        <th>UPI ID</th>
                        <td>$upi_id</td>
                    </tr>
                    <tr>
                        <th>Date & Time</th>
                        <td>$date_pay</td>
                    </tr>
                </table>
                ";
            }
            ?>
        </div>
        <button class="print-button" onclick="printPage()">Produce the Copies</button>
    </div>
</body>
</html>
