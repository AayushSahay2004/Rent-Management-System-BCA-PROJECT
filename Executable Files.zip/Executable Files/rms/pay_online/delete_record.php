<?php

session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);

// Check if ID is provided
if (isset($_GET['id'])) {
    // Get the ID from the URL parameter
    $id = $_GET['id'];

    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'rent_management_system');

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // SQL to delete record from payment_status table
    $sql = "DELETE FROM payment_status WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to pay_records.php after successful deletion
        header("Location: pay_records.php");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close connection
    $conn->close();
} else {
    // Redirect to pay_records.php if ID parameter is not provided
    header("Location: pay_records.php");
    exit();
}
?>
