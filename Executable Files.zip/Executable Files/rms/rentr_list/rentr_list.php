<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data=check_login($con);
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rent_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the reg_renter table
$sql = "SELECT id, name, age, gender, datereg, aadhar, mobile, address, roomNo, price FROM reg_renter";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Renter List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        .print-button {
            background-color: #008CBA;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        .print-button:hover {
            background-color: #007B9A;
        }
        table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4b41a;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .details-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
        .details-button:hover {
            background-color: #45a049;
        }
        .popup-panel {
            display: none;
            position: fixed;
            top: 20%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border: 2px solid #888;
            box-shadow: 0px 0px 10px 0px #000;
            z-index: 1001;
        }
        .close-button {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            float: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Renter List</h1>
        <button class="print-button" onclick="printRecords()">Print All Records</button>
        <table>
            <tr>
                <th>Name</th>
                <th>Room No.</th>
                <th>Mobile</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["roomNo"] . "</td>";
                    echo "<td>" . $row["mobile"] . "</td>";
                    echo "<td>" . $row["price"] . "</td>";
                    echo "<td><button class='details-button' onclick='showDetails(" . json_encode($row) . ")'>View Details</button></td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No records found</td></tr>";
            }
            ?>
        </table>
    </div>

    <div class="popup-panel" id="popupPanel">
        <button class="close-button" onclick="closeDetails()">Close</button>
        <div id="detailsContent"></div>
    </div>

    <script>
        function showDetails(details) {
            var popupPanel = document.getElementById("popupPanel");
            var detailsContent = document.getElementById("detailsContent");

            detailsContent.innerHTML = `
                <p><strong>Room No:</strong> ${details.roomNo}</p>
                <p><strong>ID:</strong> ${details.id}</p>
                <p><strong>Address:</strong> ${details.address}</p>
            `;

            popupPanel.style.display = "block";
        }

        function closeDetails() {
            var popupPanel = document.getElementById("popupPanel");
            popupPanel.style.display = "none";
        }

        function printRecords() {
            window.print();
        }
    </script>
    <h2><a href="../index.php">Go to Main Page</a></h2>
</body>
</html>

<?php
$conn->close();
?>
