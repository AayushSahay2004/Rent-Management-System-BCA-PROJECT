<?php
$servername = "localhost";
$username = "root"; 
$password = ""; 
$database = "rent_management_system"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $dreg = $_POST['dreg'];
    $aadhar = $_POST['aadhar'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $roomNo = $_POST['roomNo'];
    $price = $_POST['price'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO reg_renter (name, age, gender, datereg, aadhar, mobile, address, roomNo, price) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        $message = "Prepare failed: " . $conn->error;
    } else {
        $bind = $stmt->bind_param("sissssssd", $name, $age, $gender, $dreg, $aadhar, $mobile, $address, $roomNo, $price);
        if ($bind === false) {
            $message = "Bind failed: " . $stmt->error;
        } else {
            $exec = $stmt->execute();
            if ($exec === false) {
                $message = "Execute failed: " . $stmt->error;
            } else {
                $message = "New record created successfully";
            }
        }
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Rental Registration Form</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f7f7f7;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.container {
    position: relative;
    top: 95px;
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

textarea {
    resize: vertical;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

@media (max-width: 600px) {
    .container {
        padding: 15px;
    }
}

.formlinks {
            display: inline-block;
            margin: 10px 0;
            font-size: 16px;
            font-weight: bold;
        }
        .formlinks a {
            color: #007BFF;
            text-decoration: none;
        }
        .formlinks a:hover {
            color: #0056b3;
            text-decoration: underline;
        }

</style>
</head>
<body>
    <div class="container">
        <h2>Room Rental Registration Form</h2>
        <h4><a class="formlink" href="../index.php">Homepage</a>&nbsp;&nbsp;&nbsp;<a class="formlink" href="../logout.php">Logout</a></h4>
        <form id="registrationForm" action="reg_renter.php" method="post">
            <div class="form-group">
                <label for="name">Name (Applying for Renting a room):</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="age">Age:</label>
                <input type="number" id="age" name="age" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" required>
                    <option value="">Select</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label for="dob">Date of Registration:</label>
                <input type="date" id="dreg" name="dreg" required>
            </div>
            <div class="form-group">
                <label for="aadhar">ID Details (Aadhar card):</label>
                <input type="text" id="aadhar" name="aadhar" required>
            </div>
            <div class="form-group">
                <label for="mobile">Mobile No. with WhatsApp:</label>
                <input type="tel" id="mobile" name="mobile" required>
            </div>
            <div class="form-group">
                <label for="address">Address as in Aadhar card:</label>
                <textarea id="address" name="address" required></textarea>
            </div>
            <div class="form-group">
                <label for="roomNo">Room No. selected:</label>
                <input type="text" id="roomNo" name="roomNo" required>
            </div>
            <div class="form-group">
                <label for="price">Negotiated Price to Rent the Room in ₹:</label>
                <input type="number" id="price" name="price" required>
            </div>
            <button type="submit">Submit</button>
        </form>
        <?php if (!empty($message)) : ?>
        <script>
            alert('<?php echo $message; ?>');
        </script>
        <?php endif; ?>
    </div>
</body>
</html>
