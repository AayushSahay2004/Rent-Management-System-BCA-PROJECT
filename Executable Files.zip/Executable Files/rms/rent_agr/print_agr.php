<?php
session_start();
include("../connection.php");
include("../functions.php");
$user_data = check_login($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Details and Files</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .files {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .files img {
            max-width: 300px;
            height: auto;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .form-container {
            margin-top: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            width: fit-content;
        }
        .form-container input[type=text] {
            width: 100%;
            padding: 8px;
            margin-top: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }
        .form-container input[type=submit] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-container input[type=submit]:hover {
            background-color: #45a049;
        }
        .print-button {
            margin-top: 20px;
            text-align: center;
        }
        .print-button button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .print-button button:hover {
            background-color: #45a049;
        }
        #text-cont pre{
            font-family: Arial, Helvetica, sans-serif;
            font-size: 18px;font-weight: 300;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div id="text-cont">
                <pre>
                    <h3>I Ensure to Follow the rules</h3>
                Rule 1: Timely Payments will be Made.
                Rule 2: 15 day Early Notice for Vacating.
                Rule 3: The Details will be given for verificationto the nearest police station.
                Rule 4: To Ensure Good Conduct with other Tenants.
                Rule 5: To park the vehical , the tenant bears all risk.
                Rule 6: Any illegal work ,landlord is not liable. Will inform Police as soon as possible.
                Rule 7: No vandalising of the Property / Electric Bill.
                Rule 8: Forbidden to keep other as tenant in the property.
                
                
                <h3> Signature of Tenant                  Landlord Stamp</h3>
                </pre>
             </div>
            <?php if (!isset($_GET['reg_id']) || (isset($_GET['reg_id']) && !$result1->num_rows > 0 && !$result2->num_rows > 0)) : ?>
                <h2>Enter Registration ID:</h2>
                <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <input type="text" name="reg_id" placeholder="Enter Registration ID" required>
                    <input type="submit" value="Fetch Details">
                </form>
            <?php endif; ?>

            <?php
            // Database connection details
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "rent_management_system";

            // Establish connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch details from reg_renter table based on registration ID from form submission
            if (isset($_GET['reg_id'])) {
                $reg_id = $_GET['reg_id'];

                $sql1 = "SELECT id, name, age, gender, datereg, aadhar, mobile, address, roomNo, price FROM reg_renter WHERE id = ?";
                $stmt1 = $conn->prepare($sql1);
                $stmt1->bind_param("s", $reg_id);
                $stmt1->execute();
                $result1 = $stmt1->get_result();

                // Display details from reg_renter table
                if ($result1->num_rows > 0) {
                    echo "<h2>Details for Registration ID: $reg_id</h2>";
                    echo "<table>";
                    echo "<tr><th>ID</th><th>Name</th><th>Age</th><th>Gender</th><th>Date Registered</th><th>Aadhar</th><th>Mobile</th><th>Address</th><th>Room No</th><th>Price</th></tr>";
                    while ($row1 = $result1->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row1["id"] . "</td>";
                        echo "<td>" . $row1["name"] . "</td>";
                        echo "<td>" . $row1["age"] . "</td>";
                        echo "<td>" . $row1["gender"] . "</td>";
                        echo "<td>" . $row1["datereg"] . "</td>";
                        echo "<td>" . $row1["aadhar"] . "</td>";
                        echo "<td>" . $row1["mobile"] . "</td>";
                        echo "<td>" . $row1["address"] . "</td>";
                        echo "<td>" . $row1["roomNo"] . "</td>";
                        echo "<td>" . $row1["price"] . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "<p>No details found for Registration ID: $reg_id</p>";
                }

                $stmt1->close();

                // Fetch images from entries table based on ID from form submission
                $sql2 = "SELECT id, room_id, photo_path, sign_path, aadhar_path, created_at FROM entries WHERE id = ?";
                $stmt2 = $conn->prepare($sql2);
                $stmt2->bind_param("s", $reg_id);
                $stmt2->execute();
                $result2 = $stmt2->get_result();

                // Display images from entries table
                if ($result2->num_rows > 0) {
                    echo "<h2>Files for ID: $reg_id</h2>";
                    echo "<div class='files'>";
                    while ($row2 = $result2->fetch_assoc()) {
                        echo "<div><img src='" . $row2["photo_path"] . "' alt='Photograph'></div>";
                        echo "<div><img src='" . $row2["sign_path"] . "' alt='Signature'></div>";
                        echo "<div><img src='" . $row2["aadhar_path"] . "' alt='Aadhar Card'></div>";
                    }
                    echo "</div>";
                } else {
                    echo "<p style='text-align: center; margin-top: 20px;'>No files found for ID: $reg_id</p>";
                }

                $stmt2->close();
            }

            $conn->close();
            ?>
        </div>

        <?php if (isset($_GET['reg_id']) && ($result1->num_rows > 0 || $result2->num_rows > 0)) : ?>
            <div class="print-button">
                <button onclick="window.print()">Print Page</button>
            </div>
        <?php endif; ?>
    </div>
    <a href="../index.php">Go to the Main Content</a>
</body>
</html>
